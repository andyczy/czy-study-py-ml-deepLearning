python -m nmt.nmt \
    --out_dir=/tmp/nmt_model_zh \
    --inference_input_file=/tmp/my_infer_file.en \
    --inference_output_file=/tmp/output_infer
