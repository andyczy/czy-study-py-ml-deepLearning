### 18. 强化学习入门之Q Learning

运行：
```
python q_learning.py
```

由于q_learning.py 会不断刷新输出，不太适合观察，因此又提供了一个q_learning_reprint.py便于观察结果（需要pip install reprint）：

```
python q_learning_reprint.py
```
