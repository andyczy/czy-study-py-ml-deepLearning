### 13. 序列分类问题详解

本节的程序参考了项目 https://github.com/aymericdamien/TensorFlow-Examples/blob/master/examples/3_NeuralNetworks/dynamic_rnn.py ，并进行了多处修改。

直接运行即可：
```
python series_classification.py
```
